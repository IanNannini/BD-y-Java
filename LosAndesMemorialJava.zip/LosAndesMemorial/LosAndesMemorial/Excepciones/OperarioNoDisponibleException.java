package LosAndesMemorial.Excepciones;

public class OperarioNoDisponibleException extends Exception {
    
    public OperarioNoDisponibleException(String mensaje) {
        super(mensaje);
    }
}
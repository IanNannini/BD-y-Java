package LosAndesMemorial.Excepciones;

public class DocumentacionInvalidaException extends Exception {
    
    public DocumentacionInvalidaException(String mensaje) {
        super(mensaje);
    }
}
package LosAndesMemorial.Excepciones;

public class EstadoInvalidoException extends Exception {
    
    public EstadoInvalidoException(String mensaje) {
        super(mensaje);
    }
}
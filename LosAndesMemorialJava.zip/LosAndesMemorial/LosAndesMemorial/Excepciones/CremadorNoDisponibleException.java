package LosAndesMemorial.Excepciones;

public class CremadorNoDisponibleException extends Exception {
    public CremadorNoDisponibleException(String mensaje) {
        super(mensaje);
    }
}

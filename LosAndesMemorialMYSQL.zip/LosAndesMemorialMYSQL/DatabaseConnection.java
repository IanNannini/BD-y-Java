import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class DatabaseConnection {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1:3306/andes"; // Cambiar por tu nombre de base de datos
        String user = "root"; // Cambiar por tu usuario
        String password = "HALO"; // Cambiar por tu contraseña

try (Connection connection = DriverManager.getConnection(url, user, password)) {
            System.out.println("Conexión con la base de datos establecida correctamente.");
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("=== Menú Principal ===");
                System.out.println("1. Iniciar sesión");
                System.out.println("2. Salir");
                System.out.print("Seleccione una opción: ");

                int opcion = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer

                if (opcion == 2) {
                    System.out.println("Saliendo del programa. ¡Hasta luego!");
                    break;
                } else if (opcion == 1) {
                    boolean autenticado = false;

                    while (!autenticado) {
                        System.out.print("Ingrese su email: ");
                        String email = scanner.nextLine();

                        System.out.print("Ingrese su contraseña: ");
                        String contrasena = scanner.nextLine();

                        // Validar email y contraseña en la base de datos
                        String sql = "SELECT * FROM Usuario WHERE email = ? AND password = ?";
                        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                            stmt.setString(1, email);
                            stmt.setString(2, contrasena);

                            ResultSet rs = stmt.executeQuery();
                            if (rs.next()) {
                                String rol = rs.getString("rol_usuario");
                                int idusuario = rs.getInt("id");
                                System.out.println("Inicio de sesión exitoso. ¡Bienvenido " + rs.getString("nombre") + "!");
                                autenticado = true;

                                if (rol.equals("Asesor Comercial")) {
                                    // Menú exclusivo para Asesor Comercial
                                    while (true) {
                                        System.out.println("\n=== Menú Asesor Comercial ===");
                                        System.out.println("1. Solicitar servicio funerario");
                                        System.out.println("2. Salir");
                                        System.out.print("Seleccione una opción: ");

                                        int opcionMenu = scanner.nextInt();
                                        scanner.nextLine(); // Limpiar el buffer

                                        if (opcionMenu == 1) {
                                            System.out.print("Ingrese el tipo de servicio funerario (Entierro, Cremación): ");
                                            String tipoServicio = scanner.nextLine();

                                            System.out.print("Ingrese la descripción del servicio: ");
                                            String descripcion = scanner.nextLine();

                                            try {
                                                String insertSQL = "INSERT INTO ServicioFunerario (tipo_servicio, descripcion, estado_id, asesor_id, operarioAsignado_id, documentacion) "
                                                        + "VALUES (?, ?, 1, ?, NULL, 'Documentación del cliente')";
                                                try (PreparedStatement stmtInsert = connection.prepareStatement(insertSQL)) {
                                                    stmtInsert.setString(1, tipoServicio);
                                                    stmtInsert.setString(2, descripcion);
                                                    stmtInsert.setInt(3, rs.getInt("id"));

                                                    stmtInsert.executeUpdate();
                                                    System.out.println("El servicio funerario ha sido generado exitosamente.");

                                                    System.out.println("La documentación ha sido enviada para revisión.");
                                                }
                                            } catch (SQLException e) {
                                                System.err.println("Error al registrar el servicio funerario:");
                                                e.printStackTrace();
                                            }
                                        } else if (opcionMenu == 2) {
                                            System.out.println("Regresando al menú principal...");
                                            break;
                                        } else {
                                            System.out.println("Opción inválida. Intente de nuevo.");
                                        }
                                    }
                                } else if (rol.equals("Administrativo de Ventas")) {
                                    // Menú exclusivo para Administrativo de Ventas
                                    while (true) {
                                        System.out.println("\n=== Menú Administrativo de Ventas ===");
                                        System.out.println("1. Revisar documentación");
                                        System.out.println("2. Ver notificaciones");
                                        System.out.println("3. Salir");
                                        System.out.print("Seleccione una opción: ");

                                        int opcionMenu = scanner.nextInt();
                                        scanner.nextLine(); // Limpiar el buffer

                                        if (opcionMenu == 1) {
                                            try {
                                                String queryServicios = "SELECT id, descripcion, documentacion FROM ServicioFunerario WHERE estado_id = 1";
                                                try (PreparedStatement stmtServicios = connection.prepareStatement(queryServicios)) {
                                                    ResultSet rsServicios = stmtServicios.executeQuery();

                                                    System.out.println("\n=== Servicios Funerarios Pendientes ===");
                                                    boolean hayPendientes = false;

                                                    while (rsServicios.next()) {
                                                        hayPendientes = true;
                                                        int idServicio = rsServicios.getInt("id");
                                                        String descripcion = rsServicios.getString("descripcion");
                                                        String documentacion = rsServicios.getString("documentacion");

                                                        System.out.println("ID: " + idServicio + " | Descripción: " + descripcion + " | Documentación: " + documentacion);
                                                    }

                                                    if (!hayPendientes) {
                                                        System.out.println("No hay servicios funerarios pendientes de revisión.");
                                                        return;
                                                    }

                                                    System.out.print("\nIngrese el ID del servicio funerario que desea verificar: ");
                                                    int idServicioSeleccionado = scanner.nextInt();
                                                    scanner.nextLine(); // Limpiar el buffer

                                                    System.out.print("¿La documentación es correcta? (1: Sí / 2: No): ");
                                                    int respuesta = scanner.nextInt();
                                                    scanner.nextLine(); // Limpiar el buffer

                                                    if (respuesta == 1) {
                                                        String actualizarEstado = "UPDATE ServicioFunerario SET estado_id = 2 WHERE id = ?";
                                                        try (PreparedStatement stmtActualizar = connection.prepareStatement(actualizarEstado)) {
                                                            stmtActualizar.setInt(1, idServicioSeleccionado);
                                                            int filasActualizadas = stmtActualizar.executeUpdate();

                                                            if (filasActualizadas > 0) {
                                                                System.out.println("El estado del servicio funerario se ha actualizado correctamente a 'Revisado'.");
                                                            } else {
                                                                System.out.println("No se encontró el servicio funerario con el ID proporcionado.");
                                                            }
                                                        }
                                                    } else if (respuesta == 2) {
                                                        System.out.print("Ingrese la documentación corregida: ");
                                                        String nuevaDocumentacion = scanner.nextLine();

                                                        String actualizarDocumentacion = "UPDATE ServicioFunerario SET documentacion = ? WHERE id = ?";
                                                        try (PreparedStatement stmtActualizarDoc = connection.prepareStatement(actualizarDocumentacion)) {
                                                            stmtActualizarDoc.setString(1, nuevaDocumentacion);
                                                            stmtActualizarDoc.setInt(2, idServicioSeleccionado);
                                                            int filasActualizadas = stmtActualizarDoc.executeUpdate();

                                                            if (filasActualizadas > 0) {
                                                                System.out.println("La documentación se ha actualizado correctamente.");
                                                            } else {
                                                                System.out.println("No se encontró el servicio funerario con el ID proporcionado.");
                                                            }
                                                        }
                                                    } else {
                                                        System.out.println("Respuesta inválida. Regresando al menú.");
                                                    }
                                                }
                                            } catch (SQLException e) {
                                                System.err.println("Error al interactuar con la base de datos:");
                                                e.printStackTrace();
                                            }
                                        } else if (opcionMenu == 2) {
                                            String notif = "SELECT * FROM notificacion WHERE idDestinatario = ? AND mostrada = false";
                                            try (PreparedStatement stmtnotif = connection.prepareStatement(notif)) {
                                                stmtnotif.setInt(1, idusuario);
                                                ResultSet rsnotif = stmtnotif.executeQuery();

                                                while (rsnotif.next()) {
                                                    String notifFecha = rsnotif.getString("fecha");
                                                    String notifMensaje = rsnotif.getString("mensaje");
                                                    int notifId = rsnotif.getInt("id");

                                                    System.out.println(notifFecha + " " + notifMensaje);

                                                    String updateNotif = "UPDATE notificacion SET mostrada = true WHERE id = ?";
                                                    try (PreparedStatement stmtUpdate = connection.prepareStatement(updateNotif)) {
                                                        stmtUpdate.setInt(1, notifId);
                                                        stmtUpdate.executeUpdate();
                                                    }
                                                }
                                            } catch (SQLException e) {
                                                System.err.println("Error al consultar la base de datos:");
                                                e.printStackTrace();
                                            }
                                        } else if (opcionMenu == 3) {
                                            System.out.println("Regresando al menú principal...");
                                            break;
                                        } else {
                                            System.out.println("Opción inválida. Intente de nuevo.");
                                        }
                                    }
                                } else {
                                    System.out.println("Rol no soportado en esta versión. Redirigiendo al menú principal...");
                                }
                            } else {
                                System.out.println("Credenciales incorrectas. Por favor, inténtelo de nuevo.");
                            }
                        } catch (SQLException e) {
                            System.err.println("Error al consultar la base de datos:");
                            e.printStackTrace();
                        }
                    }
                } else {
                    System.out.println("Opción inválida. Intente de nuevo.");
                }
            }

            scanner.close();
        } catch (SQLException e) {
            System.err.println("Error al conectar con la base de datos:");
            e.printStackTrace();
        }
    }
}
